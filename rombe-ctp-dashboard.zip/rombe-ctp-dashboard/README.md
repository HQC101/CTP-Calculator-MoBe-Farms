# Rombe Philippines — CTP/kg Dashboard

Interactive cost-to-produce calculator linking BPS score, grower fee tiers, and flock economics.

## Local development

```bash
npm install
npm run dev
```

## Build for production

```bash
npm run build
```
Output goes to `dist/`.

## Deploy

### GitHub
```bash
git init
git add .
git commit -m "Initial commit: CTP/kg dashboard"
git remote add origin https://github.com/<your-username>/rombe-ctp-dashboard.git
git branch -M main
git push -u origin main
```

### Netlify
1. app.netlify.com → **Add new site → Import an existing project**
2. Connect GitHub, select this repo
3. Build command: `npm run build` · Publish directory: `dist`
   (already configured in `netlify.toml`)
4. Deploy

Every push to `main` auto-redeploys.
