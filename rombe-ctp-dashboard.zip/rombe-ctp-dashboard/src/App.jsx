import React, { useState, useMemo } from "react";

// ---- BPS tier table: grower fee is FLAT per HARVESTED bird ----
const TIERS = [
  { name: "Guaranteed", min: 0,   max: 324.999, fee: 28, color: "#8a6d3b" },
  { name: "Standard",   min: 325, max: 349.999, fee: 30, color: "#8d99ae" },
  { name: "Bronze",     min: 350, max: 374.999, fee: 33, color: "#b5651d" },
  { name: "Gold",       min: 375, max: 399.999, fee: 37, color: "#c99a2e" },
  { name: "Platinum",   min: 400, max: 999999,  fee: 40, color: "#3a6b5e" },
];

function getTier(bps) {
  return TIERS.find(t => bps >= t.min && bps <= t.max) || TIERS[0];
}

function Field({ label, unit, value, onChange, min, max, step }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <label style={{ fontSize: 13, fontWeight: 600, color: "#3d4a40", letterSpacing: 0.2, display: "block", marginBottom: 6 }}>
        {label}
      </label>
      <div style={{ display: "flex", alignItems: "center", border: "1px solid #d8d2c0", borderRadius: 9, overflow: "hidden", background: "#fbf9f3" }}>
        <input
          type="number"
          min={min}
          max={max}
          step={step}
          value={value}
          onChange={(e) => {
            const v = e.target.value;
            onChange(v === "" ? "" : parseFloat(v));
          }}
          style={{
            flex: 1,
            border: "none",
            outline: "none",
            background: "transparent",
            padding: "10px 12px",
            fontSize: 15,
            fontWeight: 700,
            fontFamily: "ui-monospace, monospace",
            color: "#1f2a22",
          }}
        />
        {unit ? (
          <span style={{ padding: "10px 12px", fontSize: 13, color: "#8a8f84", fontWeight: 600, borderLeft: "1px solid #e6e0d2" }}>
            {unit.trim()}
          </span>
        ) : null}
      </div>
    </div>
  );
}

export default function CTPDashboard() {
  // Live operations inputs
  const [docPrice, setDocPrice] = useState(48);       // ₱ per chick (head)
  const [feedPrice, setFeedPrice] = useState(38.5);    // ₱ per kg of feed
  const [fcr, setFcr] = useState(1.50);                // feed conversion ratio
  const [alw, setAlw] = useState(2.2);                 // average live weight, kg
  const [medPrice, setMedPrice] = useState(6.0);        // ₱ per head, medicine/vaccine
  const [harvestRecovery, setHarvestRecovery] = useState(98.0); // HR, %
  const [overhead, setOverhead] = useState(3.0);         // ₱ per head, utilities/labor/misc
  const [wah, setWah] = useState(30);                    // Weighted Average Harvest age, days
  const [quantity, setQuantity] = useState(30000);       // chicks placed (farm capacity)
  const [sellingPrice, setSellingPrice] = useState(115);  // ₱/kg liveweight, integrator's selling/contract price

  // BPS = (HR × ALW) / (FCR × WAH) × 100%   — HR entered as a percentage number (e.g. 95)
  const bps = useMemo(() => {
    const safe = (v, fb = 0) => (v === "" || v === null || v === undefined || isNaN(v) ? fb : v);
    const _hr = safe(harvestRecovery);
    const _alw = safe(alw, 0.01);
    const _fcr = safe(fcr, 0.01);
    const _wah = safe(wah, 0.01);
    if (_fcr === 0 || _wah === 0) return 0;
    return (_hr * _alw / (_fcr * _wah)) * 100;
  }, [harvestRecovery, alw, fcr, wah]);

  const tier = getTier(bps);
  const growerFeePerHeadFlat = tier.fee; // ₱28 (Bronze floor) to ₱40 (Platinum) per head

  const calc = useMemo(() => {
    const safe = (v, fallback = 0) => (v === "" || v === null || v === undefined || isNaN(v) ? fallback : v);
    const _doc = safe(docPrice), _feed = safe(feedPrice), _fcr = safe(fcr), _alw = safe(alw, 0.01),
      _med = safe(medPrice), _hr = safe(harvestRecovery), _oh = safe(overhead), _qty = safe(quantity);

    const feedCostPerHead = _feed * _fcr * _alw; // ₱ per bird, applied to harvested birds
    const growerFeePerHarvestedHead = growerFeePerHeadFlat; // paid only on birds actually harvested

    // Harvest Recovery (HR) is the survival/recovery rate directly
    const survivalRate = Math.max(0.01, _hr / 100);

    const qty = _qty;
    const headsHarvested = qty * survivalRate;
    const totalKgHarvested = headsHarvested * _alw;

    // Total feed cost = harvested birds × ALW × FCR × feed price/kg
    const totalFeedCost = headsHarvested * _alw * _fcr * _feed;

    // Costs incurred per chick placed (DOC, meds, overhead)
    const placedCostPerHead = _doc + _med + _oh;
    const totalPlacedCost = qty * placedCostPerHead;

    // Grower fee paid only on harvested heads
    const totalGrowerFee = headsHarvested * growerFeePerHarvestedHead;

    const totalCostPesos = totalPlacedCost + totalFeedCost + totalGrowerFee; // actual cash outlay for the flock
    const ctpPerKg = totalKgHarvested > 0 ? totalCostPesos / totalKgHarvested : 0;
    const ctpPerHead = headsHarvested > 0 ? totalCostPesos / headsHarvested : 0;
    const marginPerKg = (safe(sellingPrice) ) - ctpPerKg;
    const totalMargin = marginPerKg * totalKgHarvested;
    const totalRevenue = safe(sellingPrice) * totalKgHarvested;
    const grossMarginPct = totalRevenue > 0 ? (totalMargin / totalRevenue) * 100 : 0;
    const roiPct = totalCostPesos > 0 ? (totalMargin / totalCostPesos) * 100 : 0;

    const totalDocCost = qty * _doc;
    const totalMedCost = qty * _med;
    const totalOverheadCost = qty * _oh;

    // per-kg breakdown, spread across harvested liveweight
    const breakdown = totalKgHarvested > 0 ? [
      { name: "Chick (DOC)", value: totalDocCost / totalKgHarvested, color: "#c2542d" },
      { name: "Feed", value: totalFeedCost / totalKgHarvested, color: "#3a6b5e" },
      { name: "Medicine/Vax", value: totalMedCost / totalKgHarvested, color: "#c99a2e" },
      { name: "Overhead", value: totalOverheadCost / totalKgHarvested, color: "#8d99ae" },
      { name: "Grower Fee (BPS, /harvested bird)", value: totalGrowerFee / totalKgHarvested, color: "#2f5d50" },
    ] : [];

    return {
      feedCostPerHead, growerFeePerHarvestedHead, placedCostPerHead, ctpPerKg, ctpPerHead, breakdown,
      headsHarvested, totalKgHarvested, totalCostPesos, marginPerKg, totalMargin,
      totalRevenue, grossMarginPct, roiPct,
      totalDocCost, totalFeedCost, totalMedCost, totalOverheadCost, totalGrowerFee,
    };
  }, [docPrice, feedPrice, fcr, alw, medPrice, harvestRecovery, overhead, growerFeePerHeadFlat, quantity, sellingPrice]);

  return (
    <div style={{
      fontFamily: "'Inter', -apple-system, sans-serif",
      background: "#f6f3ec",
      minHeight: "100vh",
      padding: "28px 18px",
      color: "#23291f",
    }}>
      <div style={{ maxWidth: 920, margin: "0 auto" }}>

        {/* Header */}
        <div style={{ marginBottom: 22 }}>
          <div style={{ fontSize: 12, letterSpacing: 2, fontWeight: 700, color: "#8a6d3b", textTransform: "uppercase" }}>
            Rombe Philippines · Live Operations
          </div>
          <h1 style={{ fontSize: 28, margin: "4px 0 2px", fontWeight: 800, color: "#1f2a22" }}>
            Cost to Produce (CTP/kg)
          </h1>
          <div style={{ fontSize: 13.5, color: "#5b6358" }}>
            Linked to actual BPS score and tiered grower fee — preloaded with the ideal lowest-CTP, top-tier benchmark
          </div>
        </div>

        {/* Hero CTP number */}
        <div style={{
          background: "linear-gradient(135deg, #1f3b32, #2f5d50)",
          borderRadius: 16,
          padding: "22px 22px 18px",
          color: "#f6f3ec",
          marginBottom: 24,
          boxShadow: "0 10px 30px -10px rgba(31,59,50,0.5)",
        }}>
          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(4, 1fr)",
            gap: 12,
          }}>
            <div style={{ background: tier.color, borderRadius: 10, padding: "12px 14px", textAlign: "center" }}>
              <div style={{ fontSize: 11, letterSpacing: 1, textTransform: "uppercase", opacity: 0.85, fontWeight: 700 }}>
                BPS Tier
              </div>
              <div style={{ fontSize: 20, fontWeight: 800, marginTop: 2 }}>{tier.name}</div>
              <div style={{ fontSize: 12.5, fontWeight: 600, opacity: 0.9 }}>₱{tier.fee}/head</div>
            </div>

            <div style={{ background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.2)", borderRadius: 10, padding: "12px 14px", textAlign: "center" }}>
              <div style={{ fontSize: 11, letterSpacing: 1, textTransform: "uppercase", opacity: 0.85, fontWeight: 700 }}>
                CTP / Head
              </div>
              <div style={{ fontSize: 22, fontWeight: 800, fontFamily: "ui-monospace, monospace", marginTop: 2 }}>
                ₱{calc.ctpPerHead.toFixed(2)}
              </div>
            </div>

            <div style={{ background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.2)", borderRadius: 10, padding: "12px 14px", textAlign: "center" }}>
              <div style={{ fontSize: 11, letterSpacing: 1, textTransform: "uppercase", opacity: 0.85, fontWeight: 700 }}>
                CTP / Kg
              </div>
              <div style={{ fontSize: 22, fontWeight: 800, fontFamily: "ui-monospace, monospace", marginTop: 2 }}>
                ₱{calc.ctpPerKg.toFixed(2)}
              </div>
            </div>

            <div style={{ background: calc.marginPerKg >= 0 ? "#2f5d50" : "#8b2f2f", borderRadius: 10, padding: "12px 14px", textAlign: "center" }}>
              <div style={{ fontSize: 11, letterSpacing: 1, textTransform: "uppercase", opacity: 0.85, fontWeight: 700 }}>
                {calc.marginPerKg >= 0 ? "Margin / Kg" : "Loss / Kg"}
              </div>
              <div style={{ fontSize: 22, fontWeight: 800, fontFamily: "ui-monospace, monospace", marginTop: 2 }}>
                {calc.marginPerKg < 0 ? "(" : ""}₱{Math.abs(calc.marginPerKg).toFixed(2)}{calc.marginPerKg < 0 ? ")" : ""}
              </div>
            </div>
          </div>

          {/* % profit margin — distinct format */}
          <div style={{
            marginTop: 14,
            paddingTop: 12,
            borderTop: "1px solid rgba(255,255,255,0.18)",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}>
            <span style={{ fontSize: 12.5, letterSpacing: 0.5, opacity: 0.8, fontWeight: 600 }}>
              % Profit Margin vs ₱{(sellingPrice || 0).toFixed(0)}/kg selling price
            </span>
            <span style={{
              fontSize: 26, fontWeight: 800, fontFamily: "ui-monospace, monospace",
              color: calc.grossMarginPct >= 0 ? "#bfe8d8" : "#f3c4c0",
            }}>
              {calc.grossMarginPct < 0 ? "(" : ""}{Math.abs(calc.grossMarginPct).toFixed(1)}%{calc.grossMarginPct < 0 ? ")" : ""}
            </span>
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: 20 }}>

          {/* Inputs panel */}
          <div style={{
            background: "#ffffff",
            borderRadius: 14,
            padding: "20px 22px",
            border: "1px solid #e6e0d2",
          }}>
            <div style={{ fontSize: 14, fontWeight: 800, color: "#1f2a22", marginBottom: 14, textTransform: "uppercase", letterSpacing: 0.5 }}>
              Cost Inputs
            </div>

            <Field label="Flock size / farm capacity" unit=" heads placed" value={quantity} onChange={setQuantity} min={0} max={200000} step={500} />
            <Field label="Harvest Recovery (HR)" unit=" %" value={harvestRecovery} onChange={setHarvestRecovery} min={80} max={100} step={0.1} />
            <Field label="Average live weight (ALW)" unit=" kg" value={alw} onChange={setAlw} min={1.2} max={2.6} step={0.02} />
            <Field label="FCR (feed conversion ratio)" unit="" value={fcr} onChange={setFcr} min={1.3} max={2.0} step={0.01} />
            <Field label="Weighted Average Harvest age (WAH)" unit=" days" value={wah} onChange={setWah} min={20} max={55} step={0.5} />

            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", margin: "4px 0 16px" }}>
              <span style={{ fontSize: 13, fontWeight: 600, color: "#3d4a40" }}>BPS score (computed)</span>
              <span style={{ fontSize: 22, fontWeight: 800, color: "#2f5d50", fontFamily: "ui-monospace, monospace" }}>
                {bps.toFixed(1)}
              </span>
            </div>

            <div style={{ height: 1, background: "#e6e0d2", margin: "4px 0 16px" }} />

            <Field label="Chick price (DOC)" unit=" ₱/head" value={docPrice} onChange={setDocPrice} min={30} max={65} step={0.5} />
            <Field label="Feed price" unit=" ₱/kg" value={feedPrice} onChange={setFeedPrice} min={28} max={48} step={0.1} />
            <Field label="Medicine / vaccine price" unit=" ₱/head" value={medPrice} onChange={setMedPrice} min={2} max={15} step={0.1} />
            <Field label="Overhead (utilities/labor/misc)" unit=" ₱/head" value={overhead} onChange={setOverhead} min={0} max={10} step={0.1} />

            <div style={{ height: 1, background: "#e6e0d2", margin: "16px 0" }} />

            <Field label="Selling price (live/contract)" unit=" ₱/kg" value={sellingPrice} onChange={setSellingPrice} min={70} max={160} step={0.5} />

            <div style={{ fontSize: 12, color: "#5b6358", marginTop: 4 }}>
              BPS = (HR × ALW) ÷ (FCR × WAH) × 100%. Grower fee is paid per harvested bird.
              Bands: ≤324 Guaranteed ₱28 · 325–349 Standard ₱30 · 350–374 Bronze ₱33 · 375–399 Gold ₱37 · 400+ Platinum ₱40
            </div>
          </div>

          {/* Main card */}
          <div style={{
            background: "#ffffff",
            borderRadius: 14,
            padding: "20px 22px",
            border: "1px solid #e6e0d2",
          }}>
            <div style={{ fontSize: 14, fontWeight: 800, color: "#1f2a22", marginBottom: 4, textTransform: "uppercase", letterSpacing: 0.5 }}>
              Flock Cost Summary
            </div>
            <div style={{ fontSize: 12.5, color: "#5b6358", marginBottom: 14 }}>
              {(quantity || 0).toLocaleString()} heads placed at {(harvestRecovery || 0).toFixed(1)}% HR
            </div>
            <div style={{
              display: "grid",
              gridTemplateColumns: "repeat(2, 1fr)",
              gap: 10,
            }}>
              {[
                { label: "Gross Profit", value: calc.totalMargin, color: calc.totalMargin >= 0 ? "#2f5d50" : "#8b2f2f", bold: true, signed: true },
                { label: "Harvested Heads", value: calc.headsHarvested, color: "#3d4a40", count: true },
                { label: "DOC Cost", value: calc.totalDocCost, color: "#c2542d" },
                { label: "Feed Cost", value: calc.totalFeedCost, color: "#3a6b5e" },
                { label: "Medicine/Vax Cost", value: calc.totalMedCost, color: "#c99a2e" },
                { label: "Overhead", value: calc.totalOverheadCost, color: "#8d99ae" },
                { label: "Total Production Cost", value: calc.totalCostPesos, color: "#1f2a22", bold: true },
                { label: "CTP / Head", value: calc.ctpPerHead, color: "#1f2a22", bold: true, perUnit: true },
                { label: "CTP / Kilo", value: calc.ctpPerKg, color: "#1f2a22", bold: true, perUnit: true },
                { label: "Margin / Kilo", value: calc.marginPerKg, color: calc.marginPerKg >= 0 ? "#2f5d50" : "#8b2f2f", bold: true, signed: true, perUnit: true },
              ].map((s, i) => (
                <div key={i} style={{
                  background: s.signed && s.value < 0 ? "#fbe9e7" : (s.bold ? "#fbf3e3" : "#fbf9f3"),
                  border: `1px solid ${s.signed && s.value < 0 ? "#e0b0a8" : (s.bold ? "#e8d8a8" : "#e6e0d2")}`,
                  borderRadius: 10,
                  padding: "12px 14px",
                }}>
                  <div style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.3, color: s.color }}>
                    {s.label}
                  </div>
                  <div style={{ fontSize: s.bold ? 20 : 17, fontWeight: 800, fontFamily: "ui-monospace, monospace", marginTop: 4 }}>
                    {s.text
                      ? s.value
                      : s.count
                        ? s.value.toLocaleString(undefined, { maximumFractionDigits: 0 })
                        : s.signed && s.value < 0
                          ? `(₱${Math.abs(s.value).toLocaleString(undefined, { maximumFractionDigits: s.perUnit ? 2 : 0 })})${s.perUnit ? "/kg" : ""}`
                          : `₱${s.value.toLocaleString(undefined, { maximumFractionDigits: s.perUnit ? 2 : 0 })}${s.perUnit ? (s.label.includes("Head") ? "/head" : "/kg") : ""}`}
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

        <div style={{ marginTop: 24, fontSize: 11.5, color: "#8a8f84", textAlign: "center" }}>
          CTP/head = Total Cost ÷ Total Harvested Heads &nbsp;·&nbsp; CTP/kg = Total Cost ÷ Total Kilos Harvested
        </div>
      </div>
    </div>
  );
}
